import { Controller, Post, Get, Body, Param } from '@nestjs/common';
import { CreateDenunciaDto } from './dto/create-denuncia.dto';
import { Denuncia } from './entities/denuncia.entity';
import { DenunciasService } from './denuncia.service';

@Controller('denuncias')
export class DenunciasController {
  constructor(private readonly denunciasService: DenunciasService) {}

  @Post()
  async create(@Body() dto: CreateDenunciaDto): Promise<Denuncia> {
    return this.denunciasService.create(dto);
  }

  @Get()
  async findAll(): Promise<Denuncia[]> {
    return this.denunciasService.findAll();
  }

  @Get('categoria/:id')
  async findByCategoria(@Param('id') categoriaId: string): Promise<Denuncia[]> {
    return this.denunciasService.findByCategoria(categoriaId);
  }
}
