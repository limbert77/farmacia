import { ApiProperty } from '@nestjs/swagger';
import { IsString, IsNotEmpty, IsDateString } from 'class-validator';

export class CreateDenunciaDto {
  @ApiProperty({ example: '2025-05-06T14:30:00Z' })
  @IsDateString()
  fecha: string;

  @ApiProperty({ example: 'Me robaron la cartera en la plaza.' })
  @IsString()
  @IsNotEmpty()
  denuncia: string;

  @ApiProperty({ example: 'Robo' })
  @IsString()
  tipoDenuncia: string;

  @ApiProperty({ example: '66391f3dc34e1e59f878dbcb' })
  @IsString()
  userId: string;

  @ApiProperty({ example: '66391f3dc34e1e59f878dbab' })
  @IsString()
  categoriaId: string;
}
