import { Module } from '@nestjs/common';
import { DenunciasController } from './denuncia.controller';
import { DenunciasService } from './denuncia.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Denuncia } from './entities/denuncia.entity';

@Module({
  imports: [TypeOrmModule.forFeature([Denuncia])],
  controllers: [DenunciasController],
  providers: [DenunciasService],
  exports: [DenunciasService]
})
export class DenunciaModule {}
