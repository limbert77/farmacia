import { ObjectId } from 'mongodb';
import { Entity, ObjectIdColumn, Column } from 'typeorm';

@Entity('denuncias')
export class Denuncia {
  @ObjectIdColumn()
  _id: ObjectId;

  @Column()
  fecha: Date;

  @Column()
  denuncia: string;

  @Column()
  tipoDenuncia: string;

  @Column()
  userId: string;

  @Column()
  categoriaId: string;
}
