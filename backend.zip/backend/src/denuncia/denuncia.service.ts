import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Denuncia } from './entities/denuncia.entity';
import { Repository } from 'typeorm';
import { CreateDenunciaDto } from './dto/create-denuncia.dto';

@Injectable()
export class DenunciasService {
  constructor(
    @InjectRepository(Denuncia)
    private readonly denunciaRepo: Repository<Denuncia>,
  ) {}

  async create(dto: CreateDenunciaDto): Promise<Denuncia> {
    const nueva = this.denunciaRepo.create({
      ...dto,
      fecha: new Date(dto.fecha),
    });
    return this.denunciaRepo.save(nueva);
  }

  async findAll(): Promise<Denuncia[]> {
    return this.denunciaRepo.find();
  }

  async findByCategoria(categoriaId: string): Promise<Denuncia[]> {
    return this.denunciaRepo.find({ where: { categoriaId } });
  }
}
