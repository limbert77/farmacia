import { Entity, ObjectIdColumn, Column } from 'typeorm';
import { ObjectId } from 'mongodb';

@Entity('comentarios')
export class Comentario {
  @ObjectIdColumn()
  _id: ObjectId;

  @Column()
  comentario: string;

  @Column()
  fecha: Date;

  @Column()
  denunciaId: string;

  @Column()
  userId: string;
}
