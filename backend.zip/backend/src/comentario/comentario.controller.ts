import { Controller, Post, Body, Get, Query } from '@nestjs/common';
import { ComentarioService } from './comentario.service';
import { CreateComentarioDto } from './dto/create-comentario.dto';
import { Comentario } from './entities/comentario.entity';

@Controller('comentarios')
export class ComentarioController {
  constructor(private readonly comentarioService: ComentarioService) {}

  @Post()
  async create(@Body() dto: CreateComentarioDto): Promise<Comentario> {
    return this.comentarioService.create(dto);
  }

  @Get()
  async findByDenuncia(@Query('denunciaId') denunciaId: string): Promise<Comentario[]> {
    return this.comentarioService.findByDenunciaId(denunciaId);
  }
}
