import {
    WebSocketGateway,
    WebSocketServer,
    OnGatewayConnection,
    OnGatewayDisconnect,
  } from '@nestjs/websockets';
  import { Server, Socket } from 'socket.io';
  import { Comentario } from './entities/comentario.entity';
  
  @WebSocketGateway({
    cors: {
      origin: '*',
    },
  })
  export class ComentarioGateway implements OnGatewayConnection, OnGatewayDisconnect {
    @WebSocketServer()
    server: Server;
  
    handleConnection(client: Socket) {
      console.log(`Client connected: ${client.id}`);
    }
  
    handleDisconnect(client: Socket) {
      console.log(`Client disconnected: ${client.id}`);
    }
  
    emitirNuevoComentario(comentario: Comentario) {
      this.server.emit('nuevoComentario', comentario);
    }
  }
  