import { ApiProperty } from '@nestjs/swagger';
import { IsString, IsNotEmpty } from 'class-validator';

export class CreateComentarioDto {
  @ApiProperty({ example: 'Estoy de acuerdo con esta denuncia.' })
  @IsString()
  @IsNotEmpty()
  comentario: string;

  @ApiProperty({ example: '66391f3dc34e1e59f878dbcb' })
  @IsString()
  @IsNotEmpty()
  denunciaId: string;

  @ApiProperty({ example: '66391f3dc34e1e59f878abcd' })
  @IsString()
  @IsNotEmpty()
  userId: string;
}
