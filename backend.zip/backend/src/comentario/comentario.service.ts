import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Comentario } from './entities/comentario.entity';
import { Repository } from 'typeorm';
import { CreateComentarioDto } from './dto/create-comentario.dto';
import { ComentarioGateway } from './comentario.gateway';

@Injectable()
export class ComentarioService {
  constructor(
    @InjectRepository(Comentario)
    private readonly comentarioRepo: Repository<Comentario>,
    private readonly comentarioGateway: ComentarioGateway,
  ) {}

  async create(dto: CreateComentarioDto): Promise<Comentario> {
    const comentario = this.comentarioRepo.create({
      ...dto,
      fecha: new Date(),
    });
    const nuevoComentario = await this.comentarioRepo.save(comentario);
    this.comentarioGateway.emitirNuevoComentario(nuevoComentario);
    return nuevoComentario;
  }

  async findByDenunciaId(denunciaId: string): Promise<Comentario[]> {
    return this.comentarioRepo.find({ where: { denunciaId } });
  }
}
