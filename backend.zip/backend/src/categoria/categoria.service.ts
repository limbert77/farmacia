import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Categoria } from './entities/categoria.entity';
import { Repository } from 'typeorm';
import { CreateCategoriaDto } from './dto/create-categoria.dto';

@Injectable()
export class CategoriasService {
  constructor(
    @InjectRepository(Categoria)
    private readonly categoriaRepo: Repository<Categoria>,
  ) {}

  async create(dto: CreateCategoriaDto): Promise<Categoria> {
    const nuevaCategoria = this.categoriaRepo.create(dto);
    return this.categoriaRepo.save(nuevaCategoria);
  }

  async findAll(): Promise<Categoria[]> {
    return this.categoriaRepo.find();
  }

  async findByNombre(nombre: string): Promise<Categoria | null> {
    return this.categoriaRepo.findOne({ where: { nombre } });
  }
}
