import { Controller, Get, Post, Body, Query } from '@nestjs/common';
import { CreateCategoriaDto } from './dto/create-categoria.dto';
import { Categoria } from './entities/categoria.entity';
import { CategoriasService } from './categoria.service';

@Controller('categorias')
export class CategoriasController {
  constructor(private readonly categoriasService: CategoriasService) {}

  @Post()
  async create(@Body() dto: CreateCategoriaDto): Promise<Categoria> {
    return this.categoriasService.create(dto);
  }

  @Get()
  async findAll(): Promise<Categoria[]> {
    return this.categoriasService.findAll();
  }

  @Get('buscar')
  async findByNombre(@Query('nombre') nombre: string): Promise<Categoria | null> {
    return this.categoriasService.findByNombre(nombre);
  }
}
