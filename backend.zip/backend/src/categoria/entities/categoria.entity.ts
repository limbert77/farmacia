import { ObjectId } from 'mongodb';
import { Entity, ObjectIdColumn, Column } from 'typeorm';

@Entity('categorias')
export class Categoria {
  @ObjectIdColumn()
  _id: ObjectId;

  @Column()
  nombre: string;
  @Column()
  descripcion?: string;
}
