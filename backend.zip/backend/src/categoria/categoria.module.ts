import { Module } from '@nestjs/common';
import { CategoriasService } from './categoria.service';
import { CategoriasController } from './categoria.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Categoria } from './entities/categoria.entity';

@Module({
  imports: [TypeOrmModule.forFeature([Categoria])],
  providers: [CategoriasService],
  controllers: [CategoriasController],
  exports: [CategoriasService]
})
export class CategoriaModule {}
