import { Controller, Post, Body, UseGuards, Get } from '@nestjs/common';
import { User } from './entities/user.entity';
import * as bcrypt from 'bcrypt';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../auth/guards/roles.guard';
import { Roles } from '../auth/decorators/roles.decorator';
import { UsersService } from './users.service';
import { CreateUserDto } from './dto/create-user.dto';

@Controller('users')
export class UsersController {
  constructor(private readonly usersService: UsersService) {}

  @Post('register')
async create(@Body() createUserDto: CreateUserDto): Promise<Omit<User, 'password'>> {
  const hashedPassword = await bcrypt.hash(createUserDto.password, 10);
  const user = await this.usersService.create({
    username: createUserDto.username,
    password: hashedPassword,
    nombre: createUserDto.nombre,
    role: createUserDto.role || 'user',
  });
  const { password, ...userWithoutPassword } = user;
  return userWithoutPassword;
}


  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles('admin')
  @Get()
  async findAll(): Promise<Omit<User, 'password'>[]> {
    const users = await this.usersService.findAll();
    return users.map(user => {
      const { password, ...userWithoutPassword } = user;
      return userWithoutPassword;
    });
  }
}
